//
//  AppDelegate.h
//  SemaphoreTest
//
//  Created by hushunfeng on 2018/11/2.
//  Copyright © 2018 cmcc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

